# RoamMin #13 地点与天气接口核对

**总体结论为「阻塞」。** 地点前端已在本地修复异常数据兜底，真实地点接口仍待提供。天气缺少端点、数据契约和页面入口，暂时无法采集成功响应或验证前端兜底。

核对基线为 `main@a9f2be8fc61026c159a0fbf362f89268f5acaa92`。前端修复在本地 `feat/c-place-api` 上验证，改动附在 [place-fallback.patch](place-fallback.patch)。Issue 要求 11 月 25 日出结论。 [Issue #13](https://github.com/MIN-roamer-SoftwareEngineering-2026/RoamMin/issues/13)

| 验收项 | 核对结果 |
| --- | --- |
| 地点列表和详情 | 用仓库 Spring Boot 和本地 H2 实测。匿名请求均为 HTTP 401，带有效测试 JWT 均为 HTTP 500。`GET /api/v1/auth/me` 带同一 JWT 返回 HTTP 200。主分支后端无地点路由，`docs/API.md` 无地点契约。 |
| 地点前端兜底 | 基线可处理空列表、HTTP 503 和约 15 秒请求超时。返回 HTTP 200 但缺字段时，列表和详情均出现白屏。补丁添加响应结构校验，并为已知地点的空详情使用本地样例。 |
| 天气 | 主分支无天气路由、接口契约或天气展示入口。需要可测试的接口和成功响应样例才能联调。 |

## 请求和响应

### 地点真实后端

本地后端地址为 `http://127.0.0.1:8080`。下列两个请求均无请求体。匿名时省略 `Authorization`，鉴权复测时使用本地测试账户的 JWT。

```http
GET /api/v1/destinations HTTP/1.1
Host: 127.0.0.1:8080
Accept: application/json
Authorization: Bearer <local-test-token>
```

```http
GET /api/v1/destinations/sanfang-qixiang HTTP/1.1
Host: 127.0.0.1:8080
Accept: application/json
Authorization: Bearer <local-test-token>
```

两条路径返回相同的响应结构。

| 条件 | HTTP 状态 | 实测响应体 |
| --- | --- | --- |
| 匿名 | 401 | `{"code":401,"message":"Authentication required","data":null}` |
| 有效测试 JWT | 500 | `{"code":500,"message":"Internal server error","data":null}` |

两页均设计为公开访问。发布地点接口时，需由后端与 C 组确认接口的匿名访问规则和错误响应语义。 [目的地模块说明](https://github.com/MIN-roamer-SoftwareEngineering-2026/RoamMin/blob/main/docs/DESTINATION_MODULE.md)

### 地点成功响应样例

此样例用于浏览器拦截测试。列表用 `{"code":0,"message":"success","data":[<地点对象>]}`，详情用 `{"code":0,"message":"success","data":<地点对象>}`。完整对象见 [success-fixture.json](success-fixture.json)，字段按现有前端 `Destination` 类型构造。真实服务的成功响应仍待接口方提供。

### 天气接口

尚无已确认的方法、路径或参数，因此当前无法给出天气请求或真实响应样例。需要天气来源、测试端点、位置参数（如城市编码或经纬度）、鉴权要求，以及脱敏后的成功和异常响应。

## 异常截图与复测

在 Chromium 中访问 Vite 预览页面。真实场景由 Vite 代理到本地 Spring Boot。其余场景通过浏览器请求拦截构造，用于检验页面行为。超时用例延迟提供响应，Axios 按约 15 秒终止请求。

| 场景 | 修复前 | 修复后 |
| --- | --- | --- |
| 真实后端匿名 HTTP 401 | 列表和已知详情展示本地样例 | [列表](verified/screenshots/01-real-list.png) · [详情](verified/screenshots/02-real-detail.png) |
| HTTP 200，地点列表为空或已知详情为 `null` | 列表展示样例，详情显示未找到 | [列表回退](verified/screenshots/03-empty-list.png) · [详情回退](verified/screenshots/04-null-detail.png) |
| HTTP 200，地点记录仅含 `id` | 列表和详情出现 `Cannot read properties of undefined (reading 'zh')` 并白屏 | [列表回退](verified/screenshots/05-incomplete-list.png) · [详情回退](verified/screenshots/06-incomplete-detail.png) |
| HTTP 503 | 列表和详情展示本地样例 | [列表回退](verified/screenshots/07-503-list.png) · [详情回退](verified/screenshots/08-503-detail.png) |
| 响应超时 | 列表和详情展示本地样例 | [列表回退](verified/screenshots/09-timeout-list.png) · [详情回退](verified/screenshots/10-timeout-detail.png) |
| 完整的模拟成功响应 | — | [列表显示接口数据](verified/screenshots/11-valid-list.png) · [详情显示接口数据](verified/screenshots/12-valid-detail.png) |
| 未知地点详情为 `null` | — | [显示未找到](verified/screenshots/13-unknown-detail.png) |

完整机器记录见 [基线结果](baseline/results.json) 和 [修复后结果](verified/results.json)。前端 `npm run build`、改动文件的 ESLint 检查和 `git diff --check` 已通过。

## 提交清单

| 材料 | 目前进度 | 由谁补齐 |
| --- | --- | --- |
| 请求和响应示例 | 已有地点真实失败响应和模拟成功响应 | C 组黄其威与后端集成陈启扬提供可访问的地点测试环境、列表和详情真实成功样例及鉴权规则 |
| 天气请求和响应示例 | 待天气接口提供 | C 组确认天气服务负责人，提供测试端点、参数、字段和错误约定及脱敏样例 |
| 数据缺失、超时、异常的前端截图 | 地点截图已完成，天气待联调 | 天气接口及页面可测后，补天气缺数据、超时、异常时的页面证据 |
| 问题结论及依据 | 下方有可直接使用的 Issue 评论和日志 3 文案 | 在 Issue #13 发布结论和证据后，同步日志 3 |

真实接口开通后，应按实际契约复核地点字段、匿名访问规则和天气失败时的显示，再更新联调结论。

## 可直接粘贴到 Issue #13

> **核对结论为「阻塞」。** 基于 `main@a9f2be8`，在本地 Spring Boot 实测地点列表和详情。匿名请求均返回 HTTP 401，使用有效测试 JWT 均返回 HTTP 500，同一 JWT 调用 `/api/v1/auth/me` 返回 HTTP 200。主分支还未提供地点路由和接口契约，也未找到天气接口或前端天气入口。
>
> 地点前端已在本地 `feat/c-place-api` 修复成功响应缺字段导致的白屏。复测空数据、缺字段、约 15 秒超时及 HTTP 503 时，列表和已知地点详情均可回退到本地样例。完整的模拟响应可正常展示，用例及截图已整理。
>
> 请 C 组黄其威和后端集成陈启扬确认地点接口的测试地址、响应字段及公开访问规则，并提供真实成功响应。请 C 组确认天气服务负责人，提供测试端点、参数和脱敏响应样例，便于补做天气异常截图和真实联调。

## 日志 3 文案

> C 组完成 Issue #13 地点和天气接口核对，真实联调结论为「阻塞」。地点列表和详情在当前后端无法获得成功响应，天气缺少可测试接口及前端入口。已在本地分支修复地点成功响应缺字段导致的白屏，并通过空数据、缺字段、HTTP 503 和请求超时的浏览器兜底复测。下一步由 C 组和后端集成确认测试环境、字段和鉴权规则，补齐真实响应及天气异常证据。

## 复现

在基线版本的仓库根目录应用 `git apply /path/to/place-fallback.patch`，再从 `frontend/` 执行 `npm ci`、`npm run build`、`npm run preview -- --host 127.0.0.1 --port 5173`。按仓库 README 启动本地后端于 8080，测试库使用 H2 内存连接 `jdbc:h2:mem:issue13;DB_CLOSE_DELAY=-1`，本地生成 JWT 签名密钥。

Python 安装 Playwright 并执行 `python -m playwright install chromium`，再运行 `python /path/to/reproduce.py`。脚本向你启动的本地后端创建一次性测试账户用于鉴权对照。要复测修复前行为，用基线代码重新构建前端后，设置 `QA_EXPECT_BASELINE=1` 运行脚本。
