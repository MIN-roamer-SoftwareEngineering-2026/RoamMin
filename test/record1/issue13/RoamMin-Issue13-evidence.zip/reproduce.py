"""Run against the RoamMin frontend and backend started on ports 5173 and 8080."""

import asyncio
import json
import os
import shlex
from pathlib import Path
from time import monotonic
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from playwright.async_api import async_playwright, Error

ROOT = Path(__file__).resolve().parent
BASELINE = os.environ.get("QA_EXPECT_BASELINE") == "1"
OUTPUT = ROOT / ("baseline" if BASELINE else "verified")
FRONTEND = os.environ.get("QA_FRONTEND_URL", "http://127.0.0.1:5173")
BACKEND = os.environ.get("QA_BACKEND_URL", "http://127.0.0.1:8080")
DETAIL = "/destinations/sanfang-qixiang"


def request(path, *, token=None, payload=None):
    headers = {"Accept": "application/json"}
    if token:
        headers["Authorization"] = "Bearer " + token
    body = None
    if payload is not None:
        headers["Content-Type"] = "application/json"
        body = json.dumps(payload).encode()
    req = Request(BACKEND + "/api/v1" + path, data=body, headers=headers)
    try:
        response = urlopen(req, timeout=5)
    except HTTPError as error:
        response = error
    with response:
        return {"status": response.status, "body": json.load(response)}


def backend_results():
    paths = ("/destinations", DETAIL)
    result = {
        "anonymous": {path: request(path) for path in paths},
    }
    # This is a disposable account for a local development database.
    suffix = os.urandom(4).hex()
    registered = request("/auth/register", payload={
        "username": "issue13_" + suffix,
        "email": f"issue13_{suffix}@example.test",
        "password": os.urandom(14).hex(),
    })
    token = registered["body"]["data"]["token"]
    result["authenticated_control_auth_me_status"] = request("/auth/me", token=token)["status"]
    result["authenticated"] = {path: request(path, token=token) for path in paths}
    return result


async def frontend_case(browser, name, path, expected, *, response=None, status=200, delay=0):
    page = await browser.new_page(viewport={"width": 1280, "height": 840})
    errors = []
    render_failed = asyncio.Event()
    http = []
    failures = []
    endpoint = "/api/v1" + path
    def record_error(error):
        errors.append(str(error))
        render_failed.set()

    page.on("pageerror", record_error)
    page.on("response", lambda reply: http.append(reply.status) if reply.url.endswith(endpoint) else None)
    page.on("requestfailed", lambda req: failures.append(req.failure) if req.url.endswith(endpoint) else None)

    start = None
    if response is not None:
        async def handle(route):
            nonlocal start
            if start is None:
                start = monotonic()
            if delay:
                await asyncio.sleep(delay)
            try:
                await route.fulfill(status=status, json=response)
            except Error:
                if not delay:
                    raise

        await page.route("**" + endpoint, handle)

    try:
        await page.goto(FRONTEND + path, wait_until="domcontentloaded")
        if expected == "sample-list":
            await page.locator(".destination-card").first.wait_for(timeout=25000)
            assert await page.locator(".destination-card").count() == 8
            assert await page.locator(".destination-source-badge").inner_text() == "本地样例数据"
            assert not errors
        elif expected == "sample-detail":
            await page.locator(".destination-hero h1").wait_for(timeout=25000)
            assert await page.locator(".destination-hero h1").inner_text() == "三坊七巷"
            assert await page.locator(".destination-facts > div").count() == 6
            assert not errors
        elif expected == "not-found":
            await page.get_by_text("没有找到这个目的地。", exact=True).wait_for(timeout=25000)
            assert not errors
        elif expected == "render-error":
            await asyncio.wait_for(render_failed.wait(), timeout=20)
            await page.wait_for_function("document.querySelector('#root').childElementCount === 0")
            assert errors
        elif expected == "api-list":
            await page.locator(".destination-card").first.wait_for(timeout=25000)
            assert await page.locator(".destination-card").count() == 1
            assert await page.locator(".destination-source-badge").inner_text() == "地点接口数据"
            assert "接口验证" in await page.locator(".destination-card h3").inner_text()
            assert not errors
        elif expected == "api-detail":
            await page.locator(".destination-hero h1").wait_for(timeout=25000)
            assert "接口验证" in await page.locator(".destination-hero h1").inner_text()
            assert await page.locator(".destination-facts > div").count() == 6
            assert not errors
        elapsed = round(monotonic() - start, 2) if start is not None else None
        if delay:
            assert elapsed >= 14.5, elapsed
            assert failures and not http, (failures, http)
        screenshot = "screenshots/" + name + ".png"
        await page.screenshot(path=OUTPUT / screenshot, timeout=15000, animations="disabled")
        result = {
            "case": name, "path": path, "observed": expected,
            "source": "browser-intercepted response" if response is not None else "local backend via Vite",
            "http_status": sorted(set(http)), "request_failure": sorted(set(failures)),
            "browser_errors": sorted(set(errors)), "seconds_from_interception": elapsed,
            "screenshot": screenshot,
        }
        if expected == "sample-list":
            result["notice"] = await page.locator(".destination-source small").inner_text()
        print(json.dumps(result, ensure_ascii=False), flush=True)
        return result
    finally:
        await page.close()


async def main():
    (OUTPUT / "screenshots").mkdir(parents=True, exist_ok=True)
    try:
        backend = backend_results()
    except URLError as error:
        backend = {"error": str(error)}
    print(json.dumps({"backend": backend}, ensure_ascii=False), flush=True)
    success = lambda data: {"code": 0, "message": "success", "data": data}
    unavailable = {"code": 503, "message": "Service unavailable", "data": None}
    place = {"id": "sanfang-qixiang"}
    fixture = json.loads((ROOT / "success-fixture.json").read_text(encoding="utf-8"))
    async with async_playwright() as playwright:
        browser = await playwright.chromium.launch(
            executable_path=os.environ.get("QA_BROWSER"),
            args=shlex.split(os.environ.get("QA_BROWSER_ARGS", "")),
        )
        cases = [
            ("01-real-list", "/destinations", "sample-list", {}),
            ("02-real-detail", DETAIL, "sample-detail", {}),
            ("03-empty-list", "/destinations", "sample-list", {"response": success([])}),
            ("04-null-detail", DETAIL, "not-found" if BASELINE else "sample-detail", {"response": success(None)}),
            ("05-incomplete-list", "/destinations", "render-error" if BASELINE else "sample-list", {"response": success([place])}),
            ("06-incomplete-detail", DETAIL, "render-error" if BASELINE else "sample-detail", {"response": success(place)}),
            ("07-503-list", "/destinations", "sample-list", {"response": unavailable, "status": 503}),
            ("08-503-detail", DETAIL, "sample-detail", {"response": unavailable, "status": 503}),
            ("09-timeout-list", "/destinations", "sample-list", {"response": success([]), "delay": 17}),
            ("10-timeout-detail", DETAIL, "sample-detail", {"response": success(None), "delay": 17}),
        ]
        if not BASELINE:
            cases.extend([
                ("11-valid-list", "/destinations", "api-list", {"response": success([fixture])}),
                ("12-valid-detail", DETAIL, "api-detail", {"response": success(fixture)}),
                ("13-unknown-detail", "/destinations/not-in-samples", "not-found", {"response": success(None)}),
            ])
        try:
            results = await asyncio.gather(*[
                frontend_case(browser, name, path, expected, **options)
                for name, path, expected, options in cases
            ])
        finally:
            await browser.close()
    (OUTPUT / "results.json").write_text(
        json.dumps({"backend": backend, "frontend": results}, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    asyncio.run(main())
